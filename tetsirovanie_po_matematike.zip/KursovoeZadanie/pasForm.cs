﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KursovoeZadanie
{
    public partial class pasForm : Form
    {
        public pasForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string password = "qwerty";             //Пароль
            if (textBox1.Text == password)          //Если пароль верный
            {
                this.Close();
                Keys keyform = new Keys();
                keyform.Show();
            }
            else
            {                                       //Если пароль неверный
                MessageBox.Show("Пароль неверный!", "Ошибка!");
                this.Close();
                MainForm mainForm = new MainForm();
                mainForm.Show();
            }
        }
    }
}
