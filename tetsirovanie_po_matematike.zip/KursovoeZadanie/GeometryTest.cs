﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace KursovoeZadanie
{
    public partial class GeometryTest : Form
    {
        public GeometryTest()
        {
            InitializeComponent();
        }

        //Счетчик баллов
        int points = 0;
        int ocenka = 0;

        //Кнопка Завершить Тест
        private void button1_Click(object sender, EventArgs e)
        {
            //Проверка первого задания
            if (radioButton3.Checked == true)
            {
                points++;
            }

            //Проверка второго задания
            if (radioButton8.Checked == true)
            {
                points++;
            }

            //Проверка третьего задания
            if (radioButton10.Checked == true)
            {
                points++;
            }

            //Проверка четвертого задания
            if (textBox1.Text == "60")
            {
                points++;
            }

            //Проверка пятого задания
            if (textBox2.Text == "100")
            {
                points++;
            }

            //Проверка шестого задания
            if (radioButton23.Checked == true)
            {
                points++;
            }

            //Проверка седьмого задания
            if (radioButton27.Checked == true)
            {
                points++;
            }

            //Проверка восьмого задания
            if (textBox3.Text == "13")
            {
                points++;
            }

            //Проверка девятого задания
            if (textBox4.Text == "196")
            {
                points++;
            }

            //Проверка десятого задания
            if ((checkBox1.Checked == true) && (checkBox4.Checked == true))
            {
                points++;
            }

            //Условия получения двойки, вывод на экран диалогового окна
            if (points < 5)
            {
                ocenka = 2;
                MessageBox.Show("Тест не пройден!"
                    + "\nОценка за тест : "
                    + ocenka, "Увы:(");
            }

            //Условия получения тройки, вывод на экран диалогового окна
            if (points >= 5 && points < 7)
            {
                ocenka = 3;
                MessageBox.Show("Количество баллов за тест: "
                    + points
                    + "\nОценка за тест : "
                    + ocenka, "Удовлетворительно");
            }

            //Условия получения четверки, вывод на экран диалогового окна
            if (points >= 7 && points < 9)
            {
                ocenka = 4;
                MessageBox.Show("Количество баллов за тест: "
                   + points
                   + "\nОценка за тест : "
                   + ocenka, "Хорошо");
            }

            //Условия получения пятерки, вывод на экран диалогового окна
            if (points >= 9)
            {
                ocenka = 5;
                MessageBox.Show("Количество баллов за тест: "
                   + points
                   + "\nОценка за тест : "
                   + ocenka, "Отлично!");
            }
            
            //Запись результата в файл
            TextWriter sw = new StreamWriter("result_geometry.txt", true);
            sw.WriteLine(ocenka + " || (" + points + " Баллов)");
            sw.Close();

            //Закрытие формы
            this.Close();
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }
    }
}
