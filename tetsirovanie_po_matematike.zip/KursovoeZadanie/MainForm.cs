﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KursovoeZadanie
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        
        //Открытие формы для начала тестирования по алгебре
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AlgebraForm algebraForm = new AlgebraForm();
            algebraForm.Show();

        }

        //Открытие формы для начала тестирования по геометрии
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            GeometryForm geometryForm = new GeometryForm();
            geometryForm.Show();
        }

        //Закрытие приложения
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Открытие формы для просмотра результатов теста
        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            ResultsForm results = new ResultsForm();
            results.Show();
        }

        //Открытие формы с вводом пароля для просмотра ключей тестов
        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            pasForm pasform = new pasForm();
            pasform.Show();
        }
    }
}
