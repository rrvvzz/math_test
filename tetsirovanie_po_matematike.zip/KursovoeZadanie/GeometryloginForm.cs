﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace KursovoeZadanie
{
    public partial class GeometryloginForm : Form
    {
        public GeometryloginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")         //Если в namebox.Text присвоено значение
            {
                //Запись логина в файл
                TextWriter sw = new StreamWriter("login_geometry.txt", true);
                sw.WriteLine(textBox1.Text);
                sw.Close();

                //Открытие GeometryTest
                this.Hide();
                GeometryTest geometryTest = new GeometryTest();
                geometryTest.Show();
            }
            else                            //Если в namebox.Text не присвоено значение(т.е. namebox пустой) 
            {
                MessageBox.Show("Введите имя пользователя!", "Ошибка");
            }
        }
    }
}
