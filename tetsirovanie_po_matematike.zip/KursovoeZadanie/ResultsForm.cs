﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace KursovoeZadanie
{
    public partial class ResultsForm : Form
    {
        public ResultsForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }

        //Обновление таблицы с результатами по алгебре
        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            using (OpenFileDialog List = new OpenFileDialog())
            {
                listBox1.Items.AddRange(File.ReadAllLines("login_algebra.txt"));
            }
            using (OpenFileDialog List2 = new OpenFileDialog())
            {
                listBox2.Items.AddRange(File.ReadAllLines("result_algebra.txt"));
            }

        }

        //Очистка таблицы результатов по алгебре(выполняется вместе с очисткой файлов)
        private void button3_Click(object sender, EventArgs e)
        {
            {
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                File.WriteAllText("login_algebra.txt", string.Empty);
                File.WriteAllText("result_algebra.txt", string.Empty);
            }

        }

        //Обновление таблицы с результатами по геометрии
        private void button4_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            using (OpenFileDialog List = new OpenFileDialog())
            {
                listBox3.Items.AddRange(File.ReadAllLines("login_geometry.txt"));
            }
            using (OpenFileDialog List2 = new OpenFileDialog())
            {
                listBox4.Items.AddRange(File.ReadAllLines("result_geometry.txt"));
            }
        }

        //Очистка таблицы результатов по геометрии(выполняется вместе с очисткой файлов)
        private void button5_Click(object sender, EventArgs e)
        {
            {
                listBox3.Items.Clear();
                listBox4.Items.Clear();
                File.WriteAllText("login_geometry.txt", string.Empty);
                File.WriteAllText("result_geometry.txt", string.Empty);
            }
        }
    }
}
