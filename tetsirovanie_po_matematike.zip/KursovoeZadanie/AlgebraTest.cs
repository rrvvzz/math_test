﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace KursovoeZadanie
{
    public partial class AlgebraTest : Form
    {
        public AlgebraTest()
        {
            InitializeComponent();
        }

        //Счетчик баллов
        int points = 0;
        int ocenka = 0;

        //Кнопка Завершить Тест
        private void button1_Click(object sender, EventArgs e)
        {
            //Проверка первого задания
            if (radioButton4.Checked == true)
            {
                points++;
            }

            //Проверка второго задания
            if (radioButton7.Checked == true)
            {
                points++;
            }

            //Проверка третьего задания
            if (radioButton12.Checked == true)
            {
                points++;
            }

            //Проверка четвертого задания
            if (radioButton16.Checked == true)
            {
                points++;
            }

            //Проверка пятого задания
            if (radioButton18.Checked == true)
            {
                points++;
            }

            //Проверка шестого задания
            if (radioButton23.Checked == true)
            {
                points++;
            }

            //Проверка седьмого задания
            if (radioButton27.Checked == true)
            {
                points++;
            }

            //Проверка восьмого задания
            if (radioButton29.Checked == true)
            {
                points++;
            }

            //Проверка девятого задания
            if (radioButton34.Checked == true)
            {
                points++;
            }

            //Проверка десятого задания
            if (radioButton39.Checked == true)
            {
                points++;
            }

            //Условие получения двойки, вывод на экран диалогового окна
            if (points < 5)
            {
                ocenka = 2;
                MessageBox.Show("Тест не пройден!"
                    + "\nОценка за тест : "
                    + ocenka, "Увы:(");
            }

            //Услвоие получения тройки, вывод на экран диалогового окна
            if (points >= 5 && points < 7)
            {
                ocenka = 3;
                MessageBox.Show("Количество баллов за тест: "
                    + points
                    + "\nОценка за тест : "
                    + ocenka, "Удовлетворительно");
            }

            //Условие получения четверки, вывод на экран диалогового окна
            if (points >= 7 && points < 9)
            {
                ocenka = 4;
                MessageBox.Show("Количество баллов за тест: "
                   + points
                   + "\nОценка за тест : "
                   + ocenka, "Хорошо");
            }

            //Условия получения пятерки, вывод на экран диалогового окна
            if (points >= 9)
            {
                ocenka = 5;
                MessageBox.Show("Количество баллов за тест: "
                   + points
                   + "\nОценка за тест : "
                   + ocenka, "Отлично!");
            }

            //Запись результатов в файл
            TextWriter sw = new StreamWriter("result_algebra.txt", true);
            sw.WriteLine(ocenka + " || (" + points + " Баллов)");
            sw.Close();

            //Открытие MainForm
            this.Close();
            MainForm mainForm = new MainForm();
            mainForm.Show();

        }
    }
}
